# Django Rest Framework Study Material

## Source code for django rest framework


## Credits 
* @geekyshow1

* Geeky Shows: https://github.com/geekyshow1?tab=repositories

* Tutorial Link: https://www.youtube.com/watch?v=qXXC6ocTC80&list=PLbGui_ZYuhijTKyrlu-0g5GcP9nUp_HlN&index=2
